import { Routes, RouterModule }  from '@angular/router';

import { OnboardingComponent } from './onboarding.component';

// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: OnboardingComponent,
    children: [

    ]
  }
];

export const routing = RouterModule.forChild(routes);
