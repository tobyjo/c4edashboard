/*
export interface BTFStage{
    stage: string;
    stageCount: number;
}*/
export interface BTFStageGraphData{
    labels: string[];
    series: number[][];
}
