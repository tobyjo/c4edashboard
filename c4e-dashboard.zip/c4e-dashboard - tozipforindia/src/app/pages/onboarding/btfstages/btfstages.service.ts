//import { HttpModule } from '@angular/http';

import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Injectable} from '@angular/core';
import {BTFStageGraphData} from './btfstage';

import 'rxjs/add/operator/map';
import 'rxjs/Rx';
//import {BaThemeConfigProvider} from '../../../theme';

@Injectable()
export class BTFStagesService {
private baseUrl: string = "http://localhost:3001";
  private _data = {

    simpleBarData: {
      labels: ['Initiation', 'Initiation / Definition ', 'Execution', 'Pre-Initiation', 'Definition'],
      series: [
        [13, 1, 13, 3, 6]
      ]
    },
    simpleBarOptions: {
      fullWidth: true,
      height: '300px'
    }

  };

  private getHeaders(){
      let headers = new Headers();
      headers.append('Accept', 'application/json');
      return headers;
    }

  constructor(private http: Http) {
  }

public getAllData(): Observable<BTFStageGraphData>{
    console.log('getAllData');
  let graphData$ = this.http
    .get(`${this.baseUrl}/btfstages`, {headers: this.getHeaders()})
    //.map(mapStages)
    .map(extractData)
    .catch(handleError)
    .do(
      data =>
      {
        console.log(data.labels);
        console.log(data.series);
      }
    );

    console.log('got data');
    return graphData$;
}

  public getAll() {
    console.log('getAll');
    return this._data;
  }

  public getResponsive(padding, offset) {
    return [
      ['screen and (min-width: 1550px)', {
        chartPadding: padding,
        labelOffset: offset,
        labelDirection: 'explode',
        labelInterpolationFnc: function (value) {
          return value;
        }
      }],
      ['screen and (max-width: 1200px)', {
        chartPadding: padding,
        labelOffset: offset,
        labelDirection: 'explode',
        labelInterpolationFnc: function (value) {
          return value;
        }
      }],
      ['screen and (max-width: 600px)', {
        chartPadding: 0,
        labelOffset: 0,
        labelInterpolationFnc: function (value) {
          return value[0];
        }
      }]
    ];
  }
}

function handleError( error: any){
  let errorMsg = error.message || " Couldnt get btfstages date.";
  console.error(errorMsg);

  return Observable.throw(errorMsg);
}


function extractData(response:Response): BTFStageGraphData{
    console.log('extractData');

var graphData = <BTFStageGraphData>{};
graphData.labels=[]; // Initialise array
graphData.series=[]; // Initialise array
graphData.series[0]=[];
for( var i=0; i<response.json().BTFStages.length; i++)
{
  console.log(response.json().BTFStages[i]);
  graphData.labels.push(response.json().BTFStages[i].BTFStage);
  graphData.series[0].push(response.json().BTFStages[i].Count);
}

/*
let testdata = {
    labelStage: ['Initiation', 'Initiation / Definition ', 'Execution', 'Pre-Initiation', 'Definition'],
    seriesStageCount: [ 13, 1, 13, 3, 6]
  };
*/
    // Go thru response and create our object

    //return response.json().BTFStages.map(toBTFStage)
    return graphData;
}
/*
function mapStages(response:Response): BTFStage[]{
    console.log('mapStages');
    return response.json().BTFStages.map(toBTFStage)
}

function toBTFStage(r:any):BTFStage{
  let btfstage = <BTFStage>({
    stage:r.BTFStage,
    stageCount:r.Count,
  });
  console.log('Parsed BTFStage:', btfstage);
  return btfstage;
}
*/
