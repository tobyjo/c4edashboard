import {BTFStageGraphData} from './btfstages/btfstage';
import {Component, ViewEncapsulation} from '@angular/core';
import {BTFStagesService} from './btfstages/btfstages.service';
import { Observable } from 'rxjs/Rx';

@Component({
  selector: 'onboarding',
  encapsulation: ViewEncapsulation.None,
  styles: [require('./onboarding.scss')],
  providers: [BTFStagesService],
  //  template: `<strong>Onboarding stuff here</strong>`
template: require('./onboarding.html')
})

export class OnboardingComponent {

data:any;
//allData:Observable<BTFStageGraphData>;
allData : Observable<BTFStageGraphData>;
test:Observable<BTFStageGraphData>;

constructor(private _btfStagesService:BTFStagesService) {

//this.allData = <BTFStageGraphData>{};
//this.allData.labelStage=[]; // Initialise array
//this.allData.seriesStageCount=[]; // Initialise array
}

ngOnInit() {
  this.data = this._btfStagesService.getAll();
  //this._btfStagesService.getAllData().subscribe(s => this.allData = s);
  this.allData = this._btfStagesService.getAllData();

}

getResponsive(padding, offset) {
  return this._btfStagesService.getResponsive(padding, offset);
}


}
