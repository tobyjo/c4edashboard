import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgaModule } from '../../theme/nga.module';

import { OnboardingComponent } from './onboarding.component';
import { routing }       from './onboarding.routing';

//import { PieChart } from './pieChart';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    routing
  ],
  declarations: [
    OnboardingComponent
  //  PieChart

  ],
  providers: [

  //  PieChartService
  ]
})
export default class OnboardingModule {}
