export * from './chartistJs.component';
