import {Component} from '@angular/core';

@Component({
  selector: 'forms',
  styles: [],
  template: `<router-outlet></router-outlet>`
})
export class Tables {

  constructor() {
  }
}
