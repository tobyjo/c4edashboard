export * from './stripedTable.component';
