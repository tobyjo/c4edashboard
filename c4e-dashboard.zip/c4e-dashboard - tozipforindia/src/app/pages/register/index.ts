export * from './register.component';
