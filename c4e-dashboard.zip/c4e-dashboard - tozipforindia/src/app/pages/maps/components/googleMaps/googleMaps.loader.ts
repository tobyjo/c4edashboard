export const GoogleMapsLoader = require('google-maps');
