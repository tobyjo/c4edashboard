import {Component} from '@angular/core';

@Component({
  selector: 'inline-form',
  styles: [require('./inlineForm.scss')],
  template: require('./inlineForm.html'),
})
export class InlineForm {

  constructor() {
  }
}
