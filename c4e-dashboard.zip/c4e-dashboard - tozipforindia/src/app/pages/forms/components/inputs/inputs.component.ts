import {Component, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'inputs',
  encapsulation: ViewEncapsulation.None,
  template: require('./inputs.html'),
})
export class Inputs {

  constructor() {
  }
}
