export * from './baAppPicture.pipe';
