export const Chartist = require('chartist');
