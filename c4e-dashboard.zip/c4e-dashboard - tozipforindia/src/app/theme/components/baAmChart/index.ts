export * from './baAmChart.component';
