require('fullcalendar/dist/fullcalendar.js');
require('style-loader!fullcalendar/dist/fullcalendar.css');
